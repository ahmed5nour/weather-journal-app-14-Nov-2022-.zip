/* Global Variables */
//https://api.openweathermap.org/data/2.5/weather?zip=94040,us&appid={API key}
const baseWeatherURL="https://api.openweathermap.org/data/2.5/weather?";
let UserEnteredZipCode='';
const apiKey="&appid=824ec8021cdf546517079a5358a7fb05&units=metric";


// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth() + 1+'.'+ d.getDate()+'.'+ d.getFullYear();
let PostObject={};

document.getElementById('generate').addEventListener('click',GenerateButtonFunction);
function GenerateButtonFunction()
{
    UserEnteredZipCode='zip=' + document.getElementById('zip').value + ",us";

    
    retrieveData().then((returnData)=>
    {
        //console.log(returnData);
        tempObj={}; // clean
        tempObj={
        Date:` ${newDate}`,
        ZipCode:`${UserEnteredZipCode}`,
        Temprature:`${Math.round(returnData.main.temp)}`,
        UserFeeling:`${document.getElementById('feelings').value}`
        };

        Update_DOM_Elements(tempObj['Temprature'],tempObj['UserFeeling'],tempObj['Date']);

        postData('http://localhost:3000/addTemp',tempObj)
        .then((datareceived)=>{
            console.log(datareceived);
        }).catch((error)=>{console.log(error)});

    }).catch((error)=>{console.log(error)});
}


//------ update DOM elements funciton
function Update_DOM_Elements(temp,feel,date)
{
        // Write updated data to DOM elements
        document.getElementById('temp').innerHTML = temp+ ' Celcius degrees';
        document.getElementById('content').innerHTML = feel;
        document.getElementById("date").innerHTML =date;
}



///-------------- get data --------------------------------
const retrieveData = async () =>{
    const request = await fetch(baseWeatherURL + UserEnteredZipCode + apiKey);
    try {
    // Transform into JSON
    const allData = await request.json()
    
    //console.log(allData.main.temp)

    return allData;
    }
    catch(error) {
      console.log("error", error);
      // appropriately handle the error
    }
   }



//-------------------- Post Data -----------------------------
   /* Function to POST data */
const postData = async ( url = '', data = {})=>{
   // console.log(data)
      const response = await fetch(url, {
      method: 'POST', // *GET, POST, PUT, DELETE, etc.
      credentials: 'same-origin', // include, *same-origin, omit
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify(data), // body data type must match "Content-Type" header        
    });
  
      try {
        const newData = await response.json();
        // console.log(newData);
        return newData
      }catch(error) {
      console.log("error", error);
      // appropriately handle the error
      }
  }

